var isusername = false;
var isusertel = false;
var isuserpassword = false;
var isuserpassword2 = false;
var isuseryzm = false;

$(function () {	
	
	var $input = $("input");
	
	$input.each(function () {
		var t = $(this);
		//var val = t.val();
		//获得焦点事件
		t.focus(function (){
			//如果输入框内容未改变  则置为空
			if (t.val()=="用户名"||t.val()=="手机号"||t.val()=="短信验证码"||t.val()=="设置密码"||t.val()=="确认密码") {
				t.val("");
			} 
			t.prev().css("visibility","visible");//显示输入框前lable
			t.parent().find("span").css("display","block");//显示提示信息
			t.parent().find("div").css("display","none");//隐藏 OK 图片				
		});
		//焦点移除事件
		t.blur(function () {
			//用户名验证
			if (t.is("#username")) {
				if (t.val() =="") {
					t.parent().find("span").text("用户名不能为空");
				}else if(this.value.length < 4 || this.value.length > 20 ){
					t.parent().find("span").text("请输入正确的用户名，用户名应为4-12位字符");
				}else if(t.val().replace(/^\s*/,"").replace(/\s*$/,"").indexOf(" ")!=-1){
					//用户名不能含有空格
					t.parent().find("span").text("用户名不能含有空格");
				}else{
					//判断用户名是否已被使用
					var val = t.val();			
					$.post("UserServletadd",{"action":"yanzheng","val":val,"valid":"1"},function(data){
						usedname(data);
					},"json");				
				}
			}
			//手机号验证
			if (t.is("#usertel")){
				var tel = /^1(3|4|5|7|8)\d{9}$/;
				if (t.val() =="") {
					t.parent().find("span").text("手机号不能为空");
				}else{
					if(tel.test(this.value)){
						//判断是否已注册	
						var val = t.val();
						$.post("UserServletadd",{"action":"yanzheng","val":val,"valid":"2"},function(data){
							usedtel(data);
						},"json");					
					}else{
						t.parent().find("span").text("格式错误，请输入正确的手机号码");
					}
				}
			}
			//密码验证
			if (t.is("#userpassword")){
				if (t.val() =="") {
					t.parent().find("span").text("密码不能为空");
				}else if(this.value.length < 6 || this.value.length > 20){
					t.parent().find("span").text("密码长度不能小于6或者大于20");
				}else{
					t.parent().find("span").css("display","none");
					t.parent().find("div").css("display","inline-block");
					isuserpassword = true;
				}
			}
			//确认密码验证
			if (t.is("#input5")){
				if (t.val() =="") {
					t.parent().find("span").text("密码不能为空");
				}else if(t.val() !=$("#userpassword").val()) {
					t.parent().find("span").text("2次密码不一致");
				}else{
					t.parent().find("span").css("display","none");
					t.parent().find("div").css("display","inline-block");
					isuserpassword2 = true;
				}
			}
			//验证 验证码是否正确
			if(t.is("#input3")){
				if(t.val() ==""){
					t.parent().find("span").text("验证码不能为空");
				}else{
					$.post("UserServletadd",{"action":"yzm","inputyzm":$("#input3").val()},function(data){
						//返回验证码是否成功
						if(data == "ok"){
							isuseryzm = true;
						}else{
							isuseryzm = false;
						}
					},"json");
				}
					
			}		
			//判断用户名是否已被使用
			function usedname (data){
				if(data != 0){
					t.parent().find("span").text("用户名已被使用");
				}else{		
					t.parent().find("span").css("display","none");
					t.parent().find("div").css("display","inline");
					isusername = true;
				}
			}
			//判断电话号码是否已被使用
			function usedtel (data){
				if(data != 0){
					t.parent().find("span").text("手机号已被使用");
				}else{		
					t.parent().find("span").css("display","none");
					t.parent().find("div").css("display","inline");
					isusertel = true;
				}
			}
		})
	})
	

	//获取验证码
	var yzm = $("#yzm");	 
	yzm.click(function(){	
		if(isusertel){
			$.post("UserServletadd",{"action":"sendyzm","tel":$("#usertel").val()},function(data){
				//返回验证码是否成功
			},"json");
			var countdown=60; 	  
			yzm.attr('disabled',true);
			var ss = setInterval(function() {   
				if (countdown <= 0) {
					clearInterval(ss);
					yzm.attr('disabled',false);
					yzm.val("获取验证码");      
				} else {    
					yzm.val("发送验证码"+countdown);
					countdown--;   
				}   
			},1000)
		}else{
			$(this).parent().find("span").text("请输入正确的手机号");
		}
		  	
	});
	
})

function checkform(){
	if(isusername && isusertel && isuserpassword && isuserpassword2 && isuseryzm){		
		return true;
	}else{
		return false;
	}
}




