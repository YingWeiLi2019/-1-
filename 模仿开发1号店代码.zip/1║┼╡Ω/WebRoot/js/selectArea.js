

		/*written by keefelu*/
			window.onload=function(){
			    var aslt=document.getElementsByTagName('select')[1];
			    var aotn=aslt.getElementsByTagName('option')[1];
			    aslt.onchange=function(){
			        turnCity();
			    }        
			
			};
			''
			function turn(){
			    var provinceList=new Array();
				provinceList['请选择省份']=["请选择城市"];
			    provinceList['北京']=["请选择市区","东城区","西城区","崇文区","宣武区","朝阳区","丰台区","石景山区","海淀区","门头沟区","房山区","通州区","顺义区","昌平区","大兴区","怀柔区","平谷区","密云县","延庆县","延庆镇"];
			    provinceList['天津']=["请选择市区","和平区","河东区","河西区","南开区","河北区","红桥区","塘沽区","汉沽区","大港区","东丽区","西青区","津南区","北辰区","武清区","宝坻区"];
			    provinceList['河北']=["请选择市区","长安区","桥东区","桥西区","新华区","裕华区","井陉矿区","辛集市","藁城市","晋州市","新乐市","鹿泉市","井陉县","微水镇","正定县","正定镇","栾城县","栾城镇","行唐县","龙州镇","灵寿县","灵寿镇","高邑县","高邑镇","深泽县","深泽镇","赞皇县","赞皇镇","无极县","无极镇","平山县","平山镇","元氏县","槐阳镇","赵县","赵州镇"];
			    provinceList['山西']=["请选择市区","44","55"];
			    provinceList['内蒙古']=["请选择市区","44","55"];
			    provinceList['上海']=["请选择市区","黄浦区","卢湾区","徐汇区","长宁区","静安区","普陀区","闸北区","虹口区","杨浦区","闵行区","宝山区","嘉定区","浦东新区","金山区","松江区","青浦区","南汇区","奉贤区","崇明县","城桥镇"];
			    provinceList['江苏']=["请选择市区","44","55"];
			    provinceList['安徽']=["请选择市区","44","55"];
			    provinceList['浙江']=["请选择市区","44","55"];
			    var province=document.forms[0].province;//文档中的第一个省份；
			    province.options.length=0;//把province下拉列表的选项清0
			    var index=document.forms[0].country.value; //文档中的第一个国家；
			    province.options.length=0;
			    for(var j in provinceList[index]){
			        newOption=new Option(provinceList[index][j],provinceList[index][j]);
			        province.options.add(newOption);
					var city=document.forms[0].city;//文档中的第一个市区；
			        city.options.length=1;//把city下拉列表的选项清0
			    }
			}
			function turnCity(){
			        var cityList=new Array();
					cityList['请选择市区']=["请选择"];
					cityList['..']=["....."];
			        cityList['和平区']=["请选择","蓟县","宁河县","芦台镇","静海县","静海镇"];
			        cityList['江苏']=["请选择城市","南京","苏州","徐州","无锡","常州","镇江"];
			        cityList['福建']=["请选择城市","福州市","厦门市","龙岩市","钓鱼岛","冲绳","三沙市","..."];
			        cityList['11']=["请选择城市","aa","bb","cc"];
			        cityList['22']=["请选择城市","dd","ee","ff"];
					cityList['33']=["请选择城市","gg"];
			        cityList['44']=["请选择城市","hh11","iiaa","jjcc"];
			        cityList['55']=["请选择城市","kk1234","ll4567","mm8910"];
			        var city=document.forms[0].city;//文档中的第一个市区；
			        city.options.length=0;//把city下拉列表的选项清0
			        var index=document.forms[0].province.value;
			        city.options.length=0;
			        for(var j in cityList[index]){
			            newOption=new Option(cityList[index][j],cityList[index][j]);
			            city.options.add(newOption);
			        }
			
			}
		
