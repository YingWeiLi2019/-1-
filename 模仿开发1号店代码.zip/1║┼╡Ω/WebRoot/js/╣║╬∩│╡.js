$(function () {	
	
	var $carheader = $("#car-header");
	
	$("#btn-add").click(function () {
		var shang =  "<div id='product' class='product'>" +				
//					<!--商家栏-->
			"<div style='height: 50px;'>" +
				"<input type='checkbox' class='product-sj-input' />" +
				"<a href='' class='product-sj-a'>中国移动手机官方旗舰店</a>" +
				"<div class='product-sj-div' ></div>" +						
			"</div>"+
//					<!--商品信息栏-->
			"<div class='product-sx'>" +
//						<!--单选框-->
				"<input type='checkbox' id='check' class='product-sx-input' />" +
//						<!--商品图片-->
				"<img src='一号店图片/商品图片/手机.jpg' class='product-sx-img'/>" +
//						<!--商品简介-->
				"<div class='product-sx-js'>" +
					"<a href='' > Apple 苹果 iPhone8 Plus 4G手机 深空灰 移动联通版64G裸机</a><br />" +
					"<input type='text'  value='星空灰'/>" +
				"</div>" +
//						<!--价格-->
				"<p class='product-sx-wz'>5288.00</p>" +
//						<!--数量-->
				"<div class='product-sx-wz'>"+
					"<input type='button' id='jian' value='-'/>"+
					"<input type='text' id='sum' value='1' />"+
					"<input type='button' id='add' value='+' />"+
				"</div>"+
//						<!--小计-->
				"<div class='product-sx-wz'>"+
					"<p >5288.00</p>"+
					"<p >0.48kg</p>"+
				"</div>"+	
//						<!--操作-->
				"<div class='product-sx-wz'>"+
					"<input type='button' id='remove' value='删除' />"+
				"</div>"+
			"</div>"+
//					<!--商品总价栏-->
			"<div style= 'height: 50px;'>"+
				"<span class='product-sz'>"+
					"<label >商品总价：</label>"+
					"<input type='text' value='￥ 0' />"+
				"</span>"+
			"</div>"+				
		"</div>";
		$carheader.after(shang)	;
		
//		商品数量加
		$("#add").click(function () {
			var n = parseInt($("#sum").val())+1;
			$("#sum").val(n);
		})
//		商品数量减
		$("#jian").click(function () {
			var n = parseInt($("#sum").val())-1;
			if (n>=  1) {
				$("#sum").val(n);
			}			
		})
//		删除购物车内商品
		$("#remove").click(function () {
			$("#product").remove();
		})
		
		
	})
	
	$("#dizhi").click(function () {
		
	})	
	
}) 