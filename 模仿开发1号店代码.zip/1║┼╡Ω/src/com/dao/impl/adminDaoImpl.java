package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dao.inter.adminDao;
import com.util.ConnOracle;
import com.vo.Adminuser;
import com.vo.User;

public class adminDaoImpl implements adminDao {

	private Connection conn;
	
	public adminDaoImpl() {
		conn = ConnOracle.getConnection();
	}
	
	@Override
	public Adminuser getUserById(Integer auid) throws Exception {
		Adminuser lguser = new Adminuser();

		String sql = "select * from adminuser where auid=?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ��.����ͨ��
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, auid);

			// ��.ִ�в����ؽ����
			// ResultSet ����� ��װ�� ���ݿ��ѯ�Ľ����
			rs = pstmt.executeQuery();
			while (rs.next()) {
				lguser.setAuid(rs.getInt(1));
				lguser.setAdminusername(rs.getString(2));
				lguser.setAdminpassword(rs.getString(3));
			}

		} catch (SQLException e) {
			System.out.println("����ͨ��ʧ��");
			e.printStackTrace();
			throw new Exception("��ѯ�����û�ʧ��");
		} finally {
			// ��.�ر�
			ConnOracle.closeConnection(rs, pstmt, conn);

		}

		return lguser;
	}

	@Override
	public List<Adminuser> getPageByQuery(String sql) throws Exception {
		Statement stmt = null;
		ResultSet rs = null;

		List<Adminuser> list = new ArrayList<Adminuser>();

		Adminuser lguser = null;

		// ��.����ͨ��
		try {
			stmt = conn.createStatement();
			// ��.ִ�в����ؽ����
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				lguser = new Adminuser();

				lguser.setAuid(rs.getInt("auid"));
				lguser.setAdminusername(rs.getString("adminusername"));
				lguser.setAdminpassword(rs.getString("adminpassword"));
				list.add(lguser);
			}

		} catch (SQLException e) {
			System.out.println("����ͨ��ʧ��!");
			e.printStackTrace();
			throw new Exception("��ѯ�û�ʧ��");
		} finally {
			// ��.�ر�
			ConnOracle.closeConnection(rs, stmt, conn);
		}

		return list;
	}
	
	
}
