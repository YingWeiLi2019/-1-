package com.dao.inter;

import java.util.List;

import com.vo.Adminuser;



public interface adminDao {
	
	public Adminuser getUserById(Integer auid) throws Exception;
	
	public List<Adminuser> getPageByQuery(String sql) throws Exception;
}
