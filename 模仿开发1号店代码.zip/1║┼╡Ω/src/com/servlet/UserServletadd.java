package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.service.impl.UserService;
import com.vo.User;



import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.dom4j.Document;   
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;   
import org.dom4j.Element; 

public class UserServletadd extends HttpServlet {
	
	int mobile_code;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		this.doGet(request, response);
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		String action = request.getParameter("action");
		if("add".equals(action)){
			this.add(request, response);
		}else if("yanzheng".equals(action)){
			checkName(request, response);
		}else if("sendyzm".equals(action)){
			System.out.println(action);
			sendDX(request, response);
		}else if("yzm".equals(action)){
			yzm(request, response);
		}
	}
	
	//验证验证码是否正确
	public void yzm(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("application/json");
		
		String inputyzm = request.getParameter("inputyzm");
		int intyzm = Integer.parseInt(inputyzm);
		PrintWriter out = response.getWriter();
		try {
			String count = null;
			
			if(mobile_code ==intyzm){
				count = "ok";
			}else{
				count = "no";
			}
		
			 Gson json = new Gson();
			 String jsonCount = json.toJson(count);
			 out.println(jsonCount);			
			 out.flush();				
			 out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//发送验证码
	public void sendDX(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println("111");
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		
		String tel = request.getParameter("tel");

		String Url = "http://106.ihuyi.cn/webservice/sms.php?method=Submit";
		HttpClient client = new HttpClient(); 
		
		PostMethod method = new PostMethod(Url);
		client.getParams().setContentCharset("GBK");
		method.setRequestHeader("ContentType","application/x-www-form-urlencoded;charset=GBK");
		mobile_code = (int)((Math.random()*9+1)*100000);

	    String content = new String("您的验证码是：" + mobile_code + "。请不要把验证码泄露给其他人。");
		NameValuePair[] data = {//提交短信
			    new NameValuePair("account", "C01641802"), //查看用户名是登录用户中心->验证码短信->产品总览->APIID
			    new NameValuePair("password", "19f9b1d39e476aabad9b809c71944bc8"),  //查看密码请登录用户中心->验证码短信->产品总览->APIKEY
			    //new NameValuePair("password", util.StringUtil.MD5Encode("密码")),
			    new NameValuePair("mobile", tel), 
			    new NameValuePair("content", content),
		};
		method.setRequestBody(data);
		try {
			client.executeMethod(method);
			String SubmitResult =method.getResponseBodyAsString();
			//System.out.println(SubmitResult);
			Document doc = DocumentHelper.parseText(SubmitResult);
			Element root = doc.getRootElement();
			String code = root.elementText("code");
			String msg = root.elementText("msg");
			String smsid = root.elementText("smsid");
			System.out.println(code);
			System.out.println(msg);
			System.out.println(smsid);

			 if("2".equals(code)){
				System.out.println("短信提交成功");
			}

		} catch (HttpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		
		Gson json = new Gson();
		String jsonCount = json.toJson(mobile_code);
		out.println(jsonCount);			
		out.flush();				
		out.close();
	}

	//检查用户名，手机号是否重复
	public void checkName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		//设置服务器响应的数据类型  为application/json 
		response.setContentType("application/json");
		
		String val = request.getParameter("val");
		String valid = request.getParameter("valid");
		UserService service = new UserService();
		PrintWriter out = response.getWriter();
		try {
			 String count = String.valueOf(service.selectUser(valid,val));
			 System.out.println(count);
			 Gson json = new Gson();
			 String jsonCount = json.toJson(count);
			 out.println(jsonCount);			
			 out.flush();				
			 out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		//三.转发视图
	
	}
	
	//注册用户
	public void add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String target = "";
		//一.填充数据
		String name = request.getParameter("username");
		String tel = request.getParameter("usertel");
		String password = request.getParameter("userpassword");
		
		//二.调用业务逻辑
		User user = new User();
		user.setUsername(name);
		user.setPassword(password);
		user.setPhonenum(tel);
		
		UserService service = new UserService();
		try {
			service.addUser(user);
			request.setAttribute("msg", "添加用户成功");
		} catch (Exception e) {
			request.setAttribute("msg", "添加用户失败");
			e.printStackTrace();
		}
		//三.转发视图
		target = "/WEB-INF/msg.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(target);		
		rd.forward(request, response);
	} 
	
	

}
