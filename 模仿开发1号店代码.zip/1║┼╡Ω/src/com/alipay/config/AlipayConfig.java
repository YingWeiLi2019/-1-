﻿package com.alipay.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2018091361391394";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCJQb/v3YAEQboKkCTjUMVODU3LHwqBHu8AlFBKGSsgEHdD1Unir34BlQ2mITdGXlSKJlxB3vQABq+RVKVpRvhd90MKxbAPzzrefHN5UzTUod3TIj0FKsS2ORWV7e+yHZG9eCstrqYymoQJMOkzxWAp0szrl0ZXJEi9LKg7+E4ykoI2AuJQABA/jqiGcwVC+zrGQbICaqzy/aNaqXFuTUAKPwgRhDc8WnWwsncwA/kU8KhvlqjHPpgY0HqeUH2ofNetfIYQ8D0bGPeW9YTlLe1fegtN7SMjC4TiVzop7uvTwuxLKzOwX4xIcpHr95RcrfS/t9994uNEIY9tC6ISfX/lAgMBAAECggEBAIcrNPXnUFbg03HrmigyNtwyxdWu8A1QhVYwuRD/0DR3grxOo8CVyqWMQDDGrUSjSOXz+Q71nZ0Y+HVKwsr2lUkUY/WL0WMAVZ0dOirVAkYUUfvG0AjyoV5CwTsxYsgpzoikewE16X4UJMtYW5AcZCNL8XphM2hF10xVWigU1A2AQMlBFmr9DRJ4IquWgz3ja3qfhKPMd47li+YYcAHy/SGQVzuqgXO9eEnF3F3LLw5DVDJeJbPmxCNOOHixnvh2+z8tRBBd09oXdYuD6IHZfOC80mgADX8KnSL178dINEHDRuMXpheV7x89jgWGcQwi/woYPQGtn0ZkHJdvwdNY89ECgYEAx3EoUGu/8mWYAP+qwXhJApGaMczaEsNaWtvSxL1OEoCj3VcRYBfNP64ZnOrD3NGCYjP3el74yXdigD0gZXyxtOS5dA7X1KFf/aTRzHkbOl4Rl6/+fj+hfNbvG22iD8hXdQSKz/RfQMZ0XCQvocVCEYmBorsUQ6wLrrvMbMWcbmMCgYEAsC4mXRrM4XNymJj53fIMqrwz3xNWVBugUizbYOOxa+/TZK/wNcqMHbjb0KgxgpwtKnXfeHZYFbPfX8jNH3ICXfTR+L4qOZNVTohCU3mRNHbbtOMNGeOGWgzizU5EyRe3x4iCLP/QGUltdVgAmGn/HNVN7dXR96arOsg0LR3vpxcCgYAot82HPbhegKdb7Nar0Sb2w0s7x5ruIbwcuKx7RjreRC0wT0pY2AMrcRwBkVyThKKd8gYgkasxVpJhpBktHxwY1mmWbEFcQ+YZHsFGgaMxc2scEO5gUBVkK219qBBiMIDKfzbn5fhcfSfcd/bRjDhE5FH3K0Kj3kg0UFsYCfA6CQKBgBZfJdv4xT9zq3+ZHVGDpPwhPez7xaCUiX0l2Q2qnCL6pztH5BbQi45SpQcP9ImDT3Du2tuvG2xWFO1S0ElH7ukDZ45Qh4gcH18DiniTHU8uMKP9mPJKpArXTA2J/M4URu/9c5pHOaOcYVvfOuQfwZdltqmW1zy9W0zxkz6PaJktAoGBAKW4Gkzsqi2l8eBJnDqrU+a4MQyPwbxpctekW5TbsTYkPpKGDFH5MPNUWNWJ62XLRQ/ucnVBrRCvASWE0ZqR+aCOW8+bv8pkSBekRItSRda/c1U8C/A34JUmSg56/FCzy68VjLNUHFvQx+bkMep3QuMI1Nov5wdsDJElQp8Qqlbk";
	
	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiUG/792ABEG6CpAk41DFTg1Nyx8KgR7vAJRQShkrIBB3Q9VJ4q9+AZUNpiE3Rl5UiiZcQd70AAavkVSlaUb4XfdDCsWwD8863nxzeVM01KHd0yI9BSrEtjkVle3vsh2RvXgrLa6mMpqECTDpM8VgKdLM65dGVyRIvSyoO/hOMpKCNgLiUAAQP46ohnMFQvs6xkGyAmqs8v2jWqlxbk1ACj8IEYQ3PFp1sLJ3MAP5FPCob5aoxz6YGNB6nlB9qHzXrXyGEPA9Gxj3lvWE5S3tX3oLTe0jIwuE4lc6Ke7r08LsSyszsF+MSHKR6/eUXK30v7fffeLjRCGPbQuiEn1/5QIDAQAB";

	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://localhost:8080/JD2.1/notify_url.jsp";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://localhost:8080/JD2.1/mainindex.jsp";

	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipay.com/gateway.do";
	
	// 支付宝网关
	public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

