package com.service.impl;

import java.util.List;

import com.dao.impl.adminDaoImpl;
import com.service.inter.adminService;
import com.vo.Adminuser;

public class adminServiceImpl implements adminService {

	private adminDaoImpl dao = new adminDaoImpl();
	
	@Override
	public Adminuser login(String adminusername, String adminpassword)
			throws Exception {
		Adminuser lguser = null;
		
		String sql = "select * from adminuser where adminusername='" + adminusername+ "' and adminpassword='" + adminpassword + "'";
		List<Adminuser> list = dao.getPageByQuery(sql);
		if(list.size()>0){
			//�û�����
			lguser = list.get(0);
			
		}
		
		return lguser;
	}

}
