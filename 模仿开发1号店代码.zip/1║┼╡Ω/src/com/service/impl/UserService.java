package com.service.impl;

import com.dao.impl.UserDao;
import com.vo.User;



public class UserService {
	private UserDao dao;

	public UserService() {
		dao = new UserDao();
	}

	public int addUser(User user) throws Exception {

		int count = dao.addUser(user);
		return count;
	}
	
	public int selectUser(String valid,String val) throws Exception {
		int count = dao.selectUser(valid,val);
		return count;
	}
}
