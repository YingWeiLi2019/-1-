package com.service.inter;

import com.vo.Adminuser;



public interface adminService {
	public Adminuser login(String adminusername,String adminpassword) throws Exception;
}
