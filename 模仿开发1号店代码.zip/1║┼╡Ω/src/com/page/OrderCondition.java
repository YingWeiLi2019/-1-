package com.page;

public class OrderCondition {
	// ����
	private String orderCondition = "price";// Ĭ�ϰ���Ʒ��������
	private String ascOrDesc = "asc";// Ĭ������
	
	public String getOrderCondition() {
		return orderCondition;
	}
	public void setOrderCondition(String orderCondition) {
		this.orderCondition = orderCondition;
	}
	public String getAscOrDesc() {
		return ascOrDesc;
	}
	public void setAscOrDesc(String ascOrDesc) {
		this.ascOrDesc = ascOrDesc;
	}
	
	
}
