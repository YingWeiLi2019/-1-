package com.page;

//��ҳbean
public class PageInfo {

	private int totalRecordCount;//�ܹ��ж�������¼
	
	private int perPageRecordCount = 5;//ÿҳ��ʾ������
	
	private int requestPage;//����ڼ�ҳ
	
	private int begin;//�ӵڼ�����¼��ʼ��
	
	private int currentPage;//��ǰҳ
	
	private int end;//�鵽�ڼ�����¼
	
	private int totalPageCount;//�ܹ��ж���ҳ
	
	private int previousPage;
	
	private int nextPage;
	
	public void computerPreviousPage(){
		this.previousPage= (currentPage==1)?1:currentPage-1;
	}
	
	public void computerNextPage(){
		this.nextPage= (currentPage==totalPageCount)?totalPageCount:currentPage + 1;
	}
	
	
	
	public int getTotalPageCount() {
		return totalPageCount;
	}

	public void setTotalPageCount(int totalPageCount) {
		this.totalPageCount = totalPageCount;
	}

	public void computerTotalPageCount(){
		
		//totalPageCount =  �ܵļ�¼��%ÿҳ������==0?(�ܵļ�¼/ÿҳ������):(�ܵļ�¼/ÿҳ������)+1;
		this.totalPageCount = totalRecordCount%perPageRecordCount==0?(totalRecordCount/perPageRecordCount):(totalRecordCount/perPageRecordCount)+1;
	}
	
	public PageInfo(){
		
	}
	
	public PageInfo(int requestPage){
		this.requestPage = requestPage;
		
		this.begin = (requestPage-1) * perPageRecordCount + 1;
		this.end = requestPage * perPageRecordCount;
		 
		//���õ�ǰҳ  
		this.setCurrentPage(requestPage);
		
		
	}
	
	public PageInfo(int requestPage,int perPageRecordCount){
		this.requestPage = requestPage;
		this.perPageRecordCount = perPageRecordCount;
		this.begin = (requestPage-1) * perPageRecordCount + 1;
		this.end = requestPage * perPageRecordCount;
		 
		//���õ�ǰҳ  
		this.setCurrentPage(requestPage);
		
		
	}

	public int getTotalRecordCount() {
		return totalRecordCount;
	}

	public void setTotalRecordCount(int totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
		
		//�����ܹ�����ҳ  23
		this.computerTotalPageCount();//
		
		//������һҳ ����һҳ
		this.computerPreviousPage();
		this.computerNextPage();
	}

	public int getPerPageRecordCount() {
		return perPageRecordCount;
	}

	public void setPerPageRecordCount(int perPageRecordCount) {
		this.perPageRecordCount = perPageRecordCount;
	}

	public int getRequestPage() {
		return requestPage;
	}

	public void setRequestPage(int requestPage) {
		this.requestPage = requestPage;
	}

	public int getBegin() {
		return begin;
	}

	public void setBegin(int begin) {
		this.begin = begin;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPreviousPage() {
		return previousPage;
	}

	public void setPreviousPage(int previousPage) {
		this.previousPage = previousPage;
	}

	public int getNextPage() {
		return nextPage;
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	
}
