package com.vo;

public class Adminuser {
	private int auid;
	private String adminusername;
	private String adminpassword;
	private Integer isActive;
	@Override
	public String toString() {
		return "User [auid=" + auid + ", adminusername=" + adminusername
				+ ", adminpassword=" + adminpassword + ", isActive=" + isActive
				+ "]";
	}
	public int getAuid() {
		return auid;
	}
	public void setAuid(int auid) {
		this.auid = auid;
	}
	public String getAdminusername() {
		return adminusername;
	}
	public void setAdminusername(String adminusername) {
		this.adminusername = adminusername;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	public Integer getIsActive() {
		return isActive;
	}
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}
	
	
}
